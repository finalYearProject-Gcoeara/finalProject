# app.py (the one serving index.html)

import re
from flask import Flask, request, render_template, jsonify
from flask_cors import CORS
import requests
from collections import Counter # For counting sentiments

app = Flask(__name__)
CORS(app)

# Global variables
product_info = {}
reviews_data = [] # Store reviews with their sentiments
images = {}
# structured_description = "" # No longer needed if gemini_api_result is used
gemini_api_result = {} # To store product description/details
sentiment_summary = {} # To store sentiment counts and other summary data

GEMINI_API_BASE_URL = 'http://127.0.0.1:5001' # Define base URL
GEMINI_PRODUCT_URL = f'{GEMINI_API_BASE_URL}/process_product'
GEMINI_SENTIMENT_URL = f'{GEMINI_API_BASE_URL}/analyze_sentiments'


def clean_structured_description(text):
    # ... (your existing clean_structured_description function)
    if not text:
        return ""
    # Remove '**What it is:**' section
    text = re.sub(r'\*\*What it is:\*\*', '', text, flags=re.IGNORECASE)
    # Remove '**Potential Pros:**' and following bullet points
    text = re.sub(r'\*\*Potential Pros:\*\*.*?(?=(\*\*Potential Cons|\*\*|$))', '', text, flags=re.IGNORECASE | re.DOTALL)
    # Remove '**Potential Cons/Considerations:**' and following bullet points
    text = re.sub(r'\*\*Potential Cons(?:/Considerations)?:\*\*.*?(?=(\*\*|$))', '', text, flags=re.IGNORECASE | re.DOTALL)
    text = text.replace('*', '').strip()
    return text


@app.route('/')
def index():
    return render_template('index.html',
                           product_info=product_info,
                           images=images,
                           reviews_data=reviews_data, # Pass reviews with sentiments
                           gemini_data=gemini_api_result,
                           sentiment_summary=sentiment_summary) # Pass sentiment summary

@app.route('/receive_data', methods=['POST'])
def receive_data():
    global product_info, reviews_data, gemini_api_result, sentiment_summary
    data = request.get_json()
    print("Received product/reviews data:", data)

    product_info = data.get('product_info', {})
    raw_reviews = data.get('reviews', []) # List of review strings

    # --- Reset for new data ---
    reviews_data = []
    gemini_api_result = {}
    sentiment_summary = {"error": None}


    # 1. Prepare payload for Gemini Product Processing
    actual_thumbnails = images.get('thumbnails', [])
    if not actual_thumbnails and product_info.get('main_image'):
        actual_thumbnails = [product_info.get('main_image')]

    gemini_payload = {
        "images": {
            "product_name": product_info.get('product_name', ''),
            "main_image": product_info.get('main_image', ''),
            "thumbnails": actual_thumbnails
        }
    }

    try:
        response = requests.post(GEMINI_PRODUCT_URL, json=gemini_payload, timeout=10) # Added timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
        gemini_api_result = response.json()
        print("Gemini Product API Response:", gemini_api_result)

        # Clean description if present
        if "structured_description" in gemini_api_result:
            gemini_api_result["cleaned_description"] = clean_structured_description(gemini_api_result["structured_description"])
        if "food_product_details" in gemini_api_result: # Assuming no cleaning needed for food
             gemini_api_result["cleaned_description"] = gemini_api_result["food_product_details"]


    except requests.exceptions.RequestException as e:
        error_msg = f"Failed to get product details from Gemini server: {e}"
        print(error_msg)
        gemini_api_result = {"error": error_msg}
    except Exception as e:
        error_msg = f"Error processing product details: {e}"
        print(error_msg)
        gemini_api_result = {"error": error_msg}


    # 2. Analyze sentiment of reviews
    if raw_reviews:
        try:
            sentiment_payload = {"reviews": raw_reviews}
            s_response = requests.post(GEMINI_SENTIMENT_URL, json=sentiment_payload, timeout=30) # Added timeout
            s_response.raise_for_status()
            sentiment_results = s_response.json().get("sentiments", [])

            if len(sentiment_results) == len(raw_reviews):
                reviews_data = [{"text": review, "sentiment": sentiment} for review, sentiment in zip(raw_reviews, sentiment_results)]
                sentiment_counts = Counter(sentiment_results)
                sentiment_summary.update({
                    "positive": sentiment_counts.get("Positive", 0),
                    "negative": sentiment_counts.get("Negative", 0),
                    "neutral": sentiment_counts.get("Neutral", 0),
                    "unknown": sentiment_counts.get("Unknown", 0), # Gemini might return Unknown
                    "total": len(raw_reviews)
                })
                print("Sentiment Analysis Summary:", sentiment_summary)
            else:
                sentiment_summary["error"] = "Mismatch in number of reviews and sentiments received."
                reviews_data = [{"text": r, "sentiment": "Error"} for r in raw_reviews]


        except requests.exceptions.RequestException as e:
            error_msg = f"Failed to get sentiments from Gemini server: {e}"
            print(error_msg)
            sentiment_summary["error"] = error_msg
            reviews_data = [{"text": r, "sentiment": "Error"} for r in raw_reviews] # Mark as error
        except Exception as e:
            error_msg = f"Error processing sentiments: {e}"
            print(error_msg)
            sentiment_summary["error"] = error_msg
            reviews_data = [{"text": r, "sentiment": "Error"} for r in raw_reviews]
    else:
        reviews_data = []
        sentiment_summary = {"positive":0,"negative":0,"neutral":0,"unknown":0,"total":0}


    return jsonify({"message": "Data received and processed!", "product_status": "ok" if "error" not in gemini_api_result else "error", "sentiment_status": "ok" if "error" not in sentiment_summary and raw_reviews else "no_reviews_or_error"})

@app.route('/receive_images', methods=['POST'])
def receive_images():
    global images
    data = request.get_json()
    print("Received images data:", data)
    images = data.get('images', {}) # Assuming 'images' key contains a dict like {"main_image": "url", "thumbnails": ["url1", ...]}
    return jsonify({"message": "Images received successfully!"})


if __name__ == '__main__':
    app.run(debug=True, port=5000) # Default port is 5000